You can place your module specific music files in this folder

