You can place your textures in this folder
 and make the game read them by putting a 
scan_module_textures = 1
directive in module_info.txt

