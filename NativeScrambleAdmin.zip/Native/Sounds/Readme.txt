You can place your sounds in this folder
 and make the game read them by putting:

scan_module_sounds = 1

directive in module_info.txt

